import pandas as pd
import networkx as nx
# from gurobipy import *
import math
import os
import glob
import copy

resultTable = pd.read_csv('result/2_efficiency.csv')
wasteTable = pd.read_csv('result/2_efficiency_Sim.csv')
numDistricts = 8

wasteR = {}
wasteD = {}
for index, row in resultTable.iterrows():
    wasteR[row['Simulation'],row['District']] = row['WasteR']
    wasteD[row['Simulation'],row['District']] = row['WasteD']

twR = []
twD = []    
gap = []
for index, row in wasteTable.iterrows():
    totalWasteR = 0.0
    totalWasteD = 0.0
    if row['Simulation'] < 0:
        for j in range(1,numDistricts+1):
            totalWasteR += wasteR[row['Simulation'],j]
            totalWasteD += wasteD[row['Simulation'],j]
    else:            
        for j in range(numDistricts):
            totalWasteR += wasteR[row['Simulation'],j]
            totalWasteD += wasteD[row['Simulation'],j]
    twR += [totalWasteR]
    twD += [totalWasteD]    
    gap += [abs(totalWasteD-totalWasteR) / (totalWasteD + totalWasteR)]
    
wasteTable['WasteR'] = twR
wasteTable['WasteD'] = twD
wasteTable['Efficiency Gap'] = gap
            
wasteTable.to_csv(r'result/2_efficiency_Sim.csv',index=False)

