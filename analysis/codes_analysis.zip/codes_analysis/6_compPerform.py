import pandas as pd
import networkx as nx
# from gurobipy import *
import math
import os
import glob


planIDArray = []
for name in glob.glob('../result1b/process/process_b_*.csv'): # process_b_1000
    planID = int(name[30:34])
    planIDArray += [int(planID)]

planIDArray.sort()

timePlan = []
for planID in planIDArray:
    processTable = pd.read_csv('../result1b/process/process_b_%s.csv'%planID)
    timeColumn = list(processTable['Time'])
    time_ID = timeColumn[len(timeColumn)-1]
    timePlan += [time_ID]

df = pd.DataFrame()
df['Simulation'] = planIDArray
df['Time'] = timePlan

df.to_csv(r'result/6_compTime.csv',index=False)    
    
    
    