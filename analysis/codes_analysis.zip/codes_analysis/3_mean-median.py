import pandas as pd
import networkx as nx
# from gurobipy import *
import math
import os
import glob
import copy


resultTable = pd.read_csv('result/3_mean-median.csv')
mm = {}
for index,row in resultTable.iterrows():
    mm[row['Simulation'],row['District']] = row['M-M']

simList = list(set(list(resultTable['Simulation'])))
mmList = []
for simID in simList:
    mmList += [mm[simID,1]]

mmTable = pd.DataFrame()
mmTable['Simulation'] = simList
mmTable['Mean-Median'] = mmList

mmTable.to_csv(r'3_mean-median_Sim.csv',index=False)
