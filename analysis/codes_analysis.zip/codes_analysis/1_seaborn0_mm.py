import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# load the dataset
df = pd.read_csv('result/3_mean-median_Sim_no-1.csv')
df0 = pd.read_csv('result/3_mean-median_Sim.csv')

# set the background style of the plot
#sns.set_style('whitegrid')
# Set the global font size scale (e.g., to 1.5 times the default)
sns.set_theme(font_scale=3)
plt.figure(figsize=(16, 12))
min_x = np.min(df['Mean-Median'])
max_x = np.max(df['Mean-Median'])
ax = sns.kdeplot(df['Mean-Median'],clip=(min_x,max_x),lw=3,color='blue')
[existing_value] = df0.loc[df0['Simulation']==-1,'Mean-Median']
# ax = sns.kdeplot(df['TGS'])

x_data = ax.lines[0].get_xdata()
y_data = ax.lines[0].get_ydata()

# Interpolate the y-value for the specific x-value (mean_value)
# This works because the KDE curve is a continuous function, and we can estimate the density at any point
highlight_y = np.interp(existing_value, x_data, y_data)
min_y = np.interp(min_x, x_data, y_data)
max_y = np.interp(max_x, x_data, y_data)

plt.plot(min_x, min_y, 'go', markersize=20, label="Minimum")
#plt.annotate(f"Minimum: {min_x:.4f}", (min_x, min_y), color='green' ,textcoords="offset points", xytext=(0,20), ha='left')
plt.annotate(f"", (min_x, min_y), color='green' ,textcoords="offset points", xytext=(0,20), ha='left')

plt.plot(max_x, max_y, 'o',color='orange', markersize=20, label="Maximum")
#plt.annotate(f"Maximum: {max_x:.4f}", (max_x, max_y), color='orange' ,textcoords="offset points", xytext=(0,20), ha='right')
plt.annotate(f"", (max_x, max_y), color='orange' ,textcoords="offset points", xytext=(0,20), ha='right')

plt.plot(existing_value, highlight_y, 'ro', markersize=20, label="Existing")
#plt.annotate(f"Existing: {existing_value:.4f}", (existing_value, highlight_y), color='red' ,textcoords="offset points", xytext=(0,20), ha='center')
plt.annotate(f"", (existing_value, highlight_y), color='red' ,textcoords="offset points", xytext=(0,20), ha='center')
plt.axvline(x=existing_value, color='red', linestyle='--',lw=2)
# 4. Highlight the specific point using plt.scatter()
#plt.scatter(x=existing_value, y=highlight_y, color='red', zorder=10, label=f'Max ({existing_value:.2f})')

plt.xlabel('Mean-Median Difference',fontsize=60,weight='bold')

plt.show()

